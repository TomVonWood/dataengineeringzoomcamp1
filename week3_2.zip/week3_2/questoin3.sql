SELECT 
count(*),

 FROM `de-bootcamp123.fhv.fhv_native` 
 where PUlocationID is null and DOlocationID is null