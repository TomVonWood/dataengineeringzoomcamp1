    SELECT 
    count(dispatching_base_num) dispatching_base_num,
    FROM `de-bootcamp123.fhv.fhv_2019` 